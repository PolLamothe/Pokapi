<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Mon magasin</title>
</head>
<body>
    <p> Access Denied</p>
<p> <a href="<?=CFG['siteURL']?>Home"> Home </a></p>
</body>
</html>
